package com.hackerrank.sample.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.hackerrank.sample.dto.FilteredProducts;
import com.hackerrank.sample.dto.SortedProducts;

@RestController
public class SampleController {

    final String uri = "https://jsonmock.hackerrank.com/api/inventory";
    RestTemplate restTemplate = new RestTemplate();
    String result = restTemplate.getForObject(uri, String.class);           
    JSONObject root = new JSONObject(result);
    JSONArray data = root.getJSONArray("data");

    @CrossOrigin
    @GetMapping("/filter/price/{initial_price}/{final_price}")  
    private ResponseEntity<ArrayList<FilteredProducts>> filtered_books(
        @PathVariable("initial_price") int init_price,
        @PathVariable("final_price") int final_price) {

        try {
            if (init_price > final_price) {
                return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
            }

            ArrayList<FilteredProducts> books = new ArrayList<>();

            for (int i = 0; i < data.length(); i++) {
                JSONObject item = data.getJSONObject(i);
                int price = item.getInt("price");

                if (price >= init_price && price <= final_price) {
                    String barCode = item.getString("barcode");
                    books.add(new FilteredProducts(barCode, price));
                }
            }

            if (books.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            }

            return new ResponseEntity<>(books, HttpStatus.OK);

        } catch (Exception e) {
            System.out.println("Error encountered: " + e.getMessage());
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @CrossOrigin
    @GetMapping("/sort/price")
    public ResponseEntity<List<SortedProducts>> sortedBooks() {
        try {
            List<SortedProducts> products = new ArrayList<>();

            for (int i = 0; i < data.length(); i++) {
                JSONObject item = data.getJSONObject(i);
                products.add(new SortedProducts(
                        item.getString("barcode"),
                        item.getInt("price")));
            }

            products.sort(Comparator.comparingInt(SortedProducts::getPrice));

            return ResponseEntity.ok(products);

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

}
