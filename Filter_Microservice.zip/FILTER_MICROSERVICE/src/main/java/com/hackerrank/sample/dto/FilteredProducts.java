package com.hackerrank.sample.dto;

public class FilteredProducts {
    private String barCode;
    private int price;

    public FilteredProducts(String barCode, int price) {
        this.barCode = barCode;
        this.price = price;
    }

    public String getBarCode() {
        return barCode;
    }

    public void setBarCode(String barCode) {
        this.barCode = barCode;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
}
